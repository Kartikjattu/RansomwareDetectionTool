# Ransomware Detection Tool

## Overview
A hybrid ransomware detection system integrating Real-Time File Monitoring, Process Monitoring, Signature-Based Detection, and Machine Learning Analysis.

## Folder Structure
```
RansomwareDetectionTool/
│
├── app.py                 # Main Flask Application
├── monitor.py             # File System Monitor (Watchdog)
├── process_monitor.py     # Process Activity Monitor (Psutil)
├── signature_detector.py  # Signature-based Detection Logic
├── ml_model.py            # Machine Learning Model (Training & Prediction)
├── quarantine.py          # Quarantine Logic
├── database.py            # SQLite Database Management
├── utils.py               # Helper Functions (Hashing, Entropy, etc.)
├── ransomware_model.pkl   # Trained ML Model (Generated)
├── ransomware_hash_db.txt # Database of Malware Hashes
├── requirements.txt       # Python Dependencies
│
├── templates/             # HTML Templates
│   ├── index.html
│   └── logs.html
│
├── static/                # Static Assets (CSS)
│   └── style.css
│
├── quarantine/            # Quarantine Folder
├── dataset/               # Dataset Folder
└── monitor_test/          # Directory monitored for testing
```

## Features
1. **Real-Time Monitoring**: Watches `monitor_test/` for suspicious file changes.
2. **Process Analysis**: Monitors CPU usage and behavior.
3. **Signature Detection**: Checks file hashes against `ransomware_hash_db.txt`.
4. **ML Detection**: Uses Random Forest to classify behavior based on entropy, CPU usage, etc.
5. **Dashboard**: Web interface to view system health and threat logs.
6. **Auto-Quarantine**: Automatically isolates threats.

## Installation & Execution

### 1. Install Dependencies
```bash
py -m pip install -r requirements.txt
```

### 2. Train the Machine Learning Model
This generates the dataset and trains the Random Forest classifier.
```bash
py ml_model.py
```

### 3. Run the Application
Starts the web server and background monitoring threads.
```bash
py app.py
```

### 4. Access the Dashboard
Open your browser and navigate to:
[http://127.0.0.1:5000](http://127.0.0.1:5000)

## Simulation
- **Signature Detection**: Create a file, calculate its SHA256, add the hash to `ransomware_hash_db.txt`, then copy that file into `monitor_test/`.
- **Heuristic**: Rename a file with a suspicious extension like `.enc` or `.ryuk` in inside `monitor_test/`.
- **Entropy**: Copy a high-entropy file (like an encrypted zip) into `monitor_test/`.
