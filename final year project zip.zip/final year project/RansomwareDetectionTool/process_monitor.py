import psutil
import time
import pandas as pd
import numpy as np
import threading
from database import log_incident
from ml_model import predict_threat

# Thresholds
HIGH_CPU_THRESHOLD = 80
HIGH_DISK_WRITE_THRESHOLD = 1000  # Number of write ops in short interval

def monitor_processes(interval=2):
    """
    Monitors running processes for suspicious activity.
    """
    print("[*] Starting Process Monitor...")
    
    while True:
        try:
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'status', 'num_threads']):
                try:
                    p_info = proc.info
                    
                    # Ignore system processes or benign ones
                    if p_info['status'] == psutil.STATUS_ZOMBIE:
                        continue
                    if not p_info['name']:
                        continue
                    
                    cpu_percent = p_info['cpu_percent']
                    
                    # Simplified heuristic for disk usage since exact bytes/sec per process is tricky cross-platform
                    # Using io_counters if available
                    io_counters = proc.io_counters() if hasattr(proc, 'io_counters') else None
                    write_count = io_counters.write_count if io_counters else 0
                    
                    # ML Check (Simulated for this script as we don't have real-time per-second stats easily)
                    # Use current CPU and some randomized/heuristic values for other features
                    # Features: CPU, File Mod Rate, Entropy, Write Freq, Ext Anomaly
                    
                    # Heuristic Check
                    if cpu_percent > HIGH_CPU_THRESHOLD:
                        print(f"[!] High CPU Usage Detected: {p_info['name']} (PID: {p_info['pid']}) - CPU: {cpu_percent}%")
                        log_incident("Process", p_info['name'], "High CPU Usage", "Medium", "Alerted")
                        
                        # Simulate ML prediction trigger
                        is_ransomware = predict_threat(cpu_percent, 10, 5, write_count % 100, 0) # Mock values for other params
                        
                        if is_ransomware:
                            print(f"[!!!] POTENTIAL RANSOMWARE DETECTED: {p_info['name']}")
                            log_incident("Process", p_info['name'], "ML Detection: Ransomware Behavior", "High", "Terminated (Simulated)")
                            # In real scenario: proc.kill()
                            
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass
            
            time.sleep(interval)
            
        except Exception as e:
            print(f"Error in process monitor: {e}")
            time.sleep(interval)

if __name__ == "__main__":
    monitor_processes()
