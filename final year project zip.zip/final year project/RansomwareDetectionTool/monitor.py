import hashlib
import os
import shutil
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from ml_model import predict_threat
from signature_detector import check_file_signature
from utils import calculate_entropy, is_suspicious_extension, move_to_quarantine
from database import log_incident

MONITOR_DIR = "./monitor_test" # Change this to the directory you want to monitor

class RansomwareMonitor(FileSystemEventHandler):
    """
    Watches for suspicious file system events.
    """
    
    def on_modified(self, event):
        self.process_event(event)
    
    def on_created(self, event):
        self.process_event(event)

    def on_moved(self, event):
        self.process_event(event)

    def process_event(self, event):
        if event.is_directory:
            return
        
        file_path = event.src_path
        filename = os.path.basename(file_path)
        
        print(f"[EVENT] File Adjusted: {file_path}")
        
        # 1. Signature Check
        is_malware = check_file_signature(file_path)
        if is_malware:
            print(f"[DETECTED] Known Malware (Signature): {file_path}")
            move_to_quarantine(file_path)
            return

        # 2. Heuristic: Suspicious Extension
        if is_suspicious_extension(filename):
            print(f"[DETECTED] Suspicious Extension: {file_path}")
            log_incident("File", filename, "Suspicious Extension", "Medium", "Quarantined")
            move_to_quarantine(file_path)
            return

        # 3. Behavioral: High Entropy (Simulated for this implementation)
        entropy = calculate_entropy(file_path)
        if entropy > 7.5: # Encrypted data typically has higher entropy
            print(f"[DETECTED] High Entropy (Encryption-like): {file_path} (Entropy: {entropy})")
            log_incident("File", filename, "High Entropy", "High", "Quarantined")
            move_to_quarantine(file_path)
            return

        # 4. ML Heuristic (Basic Integration)
        # Using placeholder values for features that would need real-time aggregation
        # In a real tool, you'd aggregate these over time windows for the specific file
        # Cpu usage (Process doing the change) is tricky here without OS hooks, so we estimate
        mock_cpu = 50 
        mock_mod_rate = 1 # Files changed recently
        mock_write_freq = 1
        
        ml_prediction = predict_threat(mock_cpu, mock_mod_rate, entropy, mock_write_freq, 0)
        if ml_prediction == 1:
            print(f"[DETECTED] ML Model Flagged Activity: {file_path}")
            log_incident("File", filename, "ML Anomaly", "High", "Quarantined")
            move_to_quarantine(file_path)

def start_monitor():
    event_handler = RansomwareMonitor()
    observer = Observer()
    if not os.path.exists(MONITOR_DIR):
        os.makedirs(MONITOR_DIR)
        
    observer.schedule(event_handler, path=MONITOR_DIR, recursive=True)
    observer.start()
    print(f"[*] Monitoring directory: {MONITOR_DIR}")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

if __name__ == "__main__":
    start_monitor()
