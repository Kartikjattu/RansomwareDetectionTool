import os
import shutil
import datetime
from database import log_incident

QUARANTINE_DIR = "quarantine"

if not os.path.exists(QUARANTINE_DIR):
    os.makedirs(QUARANTINE_DIR)

def quarantine_file(file_path, reason="Suspicious Activity"):
    """
    Moves a file to the quarantine directory and logs the action.
    """
    try:
        filename = os.path.basename(file_path)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        new_filename = f"{timestamp}_{filename}"
        destination = os.path.join(QUARANTINE_DIR, new_filename)
        
        shutil.move(file_path, destination)
        print(f"[QUARANTINE] Moved {file_path} -> {destination}")
        
        log_incident("File", filename, reason, "High", "Quarantined")
        return True
    except Exception as e:
        print(f"Failed to quarantine {file_path}: {e}")
        return False

def restore_file(quarantined_file, original_location):
    """
    Restores a file from quarantine to its original location.
    """
    try:
        shutil.move(quarantined_file, original_location)
        print(f"[rESTORE] Restored {quarantined_file} -> {original_location}")
        return True
    except Exception as e:
        print(f"Failed to restore {quarantined_file}: {e}")
        return False
