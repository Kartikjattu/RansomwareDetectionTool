import hashlib
import math
import os
import shutil
import time

def calculate_sha256(file_path):
    """Calculates SHA256 of a file."""
    try:
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    except Exception as e:
        print(f"Error calculating hash for {file_path}: {e}")
        return None

def calculate_entropy(file_path):
    """Calculates Shannon entropy of a file to detect encryption."""
    try:
        with open(file_path, 'rb') as f:
            data = f.read()
        if not data:
            return 0
        entropy = 0
        for x in range(256):
            p_x = float(data.count(bytes([x]))) / len(data)
            if p_x > 0:
                entropy += - p_x * math.log(p_x, 2)
        return entropy
    except Exception as e:
        print(f"Error calculating entropy for {file_path}: {e}")
        return 0

def move_to_quarantine(file_path, quarantine_folder="quarantine"):
    """Moves a file to the quarantine folder."""
    try:
        if not os.path.exists(quarantine_folder):
            os.makedirs(quarantine_folder)
        
        filename = os.path.basename(file_path)
        destination = os.path.join(quarantine_folder, filename)
        shutil.move(file_path, destination)
        return True, destination
    except Exception as e:
        print(f"Error moving to quarantine: {e}")
        return False, str(e)

def is_suspicious_extension(filename):
    """Checks for known ransomware extensions."""
    SUSPICIOUS_EXTENSIONS = [".enc", ".locked", ".crypto", ".pay", ".crypt", ".ryuk", ".wannacry"]
    return any(filename.endswith(ext) for ext in SUSPICIOUS_EXTENSIONS)
