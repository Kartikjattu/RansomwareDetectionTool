import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib
import os

MODEL_FILE = "ransomware_model.pkl"
DATASET_FILE = "dataset/ransomware_dataset.csv"

# Features:
# 1. cpu_usage (0-100)
# 2. file_mod_rate (modifications per second)
# 3. entropy (0-8)
# 4. write_frequency (writes per second)
# 5. extension_anomaly (0 or 1)
# Target: 0 (Benign), 1 (Ransomware)

def generate_dataset():
    """Generates a synthetic dataset if it doesn't exist."""
    if os.path.exists(DATASET_FILE):
        return

    print("Generating synthetic dataset...", flush=True)
    
    # Benign data (Normal usage)
    n_benign = 1000
    benign_data = {
        'cpu_usage': np.random.normal(15, 10, n_benign),
        'file_mod_rate': np.random.exponential(1, n_benign),
        'entropy': np.random.normal(4, 1, n_benign),
        'write_frequency': np.random.exponential(2, n_benign),
        'extension_anomaly': np.zeros(n_benign),
        'target': np.zeros(n_benign)
    }

    # Ransomware data (High CPU, high entropy, rapid mods)
    n_malware = 1000
    malware_data = {
        'cpu_usage': np.random.normal(80, 15, n_malware), # High CPU
        'file_mod_rate': np.random.exponential(50, n_malware), # Rapid mods
        'entropy': np.random.normal(7.5, 0.5, n_malware), # High entropy (encryption)
        'write_frequency': np.random.exponential(40, n_malware), # Frequent writes
        'extension_anomaly': np.ones(n_malware),
        'target': np.ones(n_malware)
    }

    df_benign = pd.DataFrame(benign_data)
    df_malware = pd.DataFrame(malware_data)
    
    df = pd.concat([df_benign, df_malware])
    
    # Clip values to realistic ranges
    df['cpu_usage'] = df['cpu_usage'].clip(0, 100)
    df['entropy'] = df['entropy'].clip(0, 8)
    
    df.to_csv(DATASET_FILE, index=False)
    print(f"Dataset saved to {DATASET_FILE}")

def train_model():
    """Trains the Random Forest model."""
    if not os.path.exists(DATASET_FILE):
        generate_dataset()
        
    df = pd.read_csv(DATASET_FILE)
    X = df.drop('target', axis=1)
    y = df['target']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Model Accuracy: {acc * 100:.2f}%")
    
    joblib.dump(model, MODEL_FILE)
    print(f"Model saved to {MODEL_FILE}", flush=True)

def predict_threat(cpu_usage, file_mod_rate, entropy, write_freq, ext_anomaly):
    """Predicts if the behavior is ransomware using the trained model."""
    if not os.path.exists(MODEL_FILE):
        print("Model not found. Please train first.")
        return 0

    model = joblib.load(MODEL_FILE)
    # Use DataFrame to avoid feature name warning
    features = pd.DataFrame([[cpu_usage, file_mod_rate, entropy, write_freq, ext_anomaly]], 
                            columns=['cpu_usage', 'file_mod_rate', 'entropy', 'write_frequency', 'extension_anomaly'])
    prediction = model.predict(features)
    return prediction[0]

if __name__ == "__main__":
    train_model()
