import os
import hashlib
from utils import calculate_sha256, move_to_quarantine
from database import log_incident

HASH_DB_FILE = 'ransomware_hash_db.txt'

def load_hashes():
    """Loads malicious hashes from file."""
    try:
        with open(HASH_DB_FILE, 'r') as f:
            return set(line.strip() for line in f if not line.startswith('#') and line.strip())
    except FileNotFoundError:
        print("Hash database not found.")
        return set()

MALICIOUS_HASHES = load_hashes()

def check_file_signature(file_path):
    """Checks if a file matches a known ransomware hash."""
    file_hash = calculate_sha256(file_path)
    if not file_hash:
        return False

    if file_hash in MALICIOUS_HASHES:
        print(f"[!] Signature Match: {file_path}")
        move_to_quarantine(file_path)
        log_incident("File", os.path.basename(file_path), "Signature Match", "High", "Quarantined")
        return True
    return False
