import sqlite3
import datetime

DB_NAME = "ransomware_logs.db"

def init_db():
    """Initializes the SQLite database with the logs table."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT NOT NULL,
                        source_type TEXT NOT NULL,  -- Process or File
                        name TEXT NOT NULL,
                        threat_type TEXT NOT NULL,
                        severity TEXT NOT NULL,
                        action_taken TEXT NOT NULL
                    )''')
    conn.commit()
    conn.close()

def log_incident(source_type, name, threat_type, severity, action_taken):
    """Logs a security incident."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("INSERT INTO logs (timestamp, source_type, name, threat_type, severity, action_taken) VALUES (?, ?, ?, ?, ?, ?)",
                   (timestamp, source_type, name, threat_type, severity, action_taken))
    conn.commit()
    conn.close()

def get_logs():
    """Fetches all logs for the dashboard."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM logs ORDER BY id DESC")
    logs = cursor.fetchall()
    conn.close()
    return logs

if __name__ == "__main__":
    init_db()
    print("Database Initialized.")
