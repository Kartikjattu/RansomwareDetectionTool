from flask import Flask, render_template, jsonify
import sqlite3
import threading
import os
import psutil
from monitor import start_monitor
from process_monitor import monitor_processes
from process_monitor import monitor_processes
from database import get_logs
from flask import request
from werkzeug.utils import secure_filename
from utils import calculate_sha256, calculate_entropy, is_suspicious_extension
from signature_detector import check_file_signature, MALICIOUS_HASHES
import math

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Start monitoring threads
def start_background_monitoring():
    thread_file = threading.Thread(target=start_monitor)
    thread_file.daemon = True
    thread_file.start()

    thread_proc = threading.Thread(target=monitor_processes)
    thread_proc.daemon = True
    thread_proc.start()

@app.route('/')
def home():
    # Simple stats for dashboard
    logs = get_logs()
    
    cpu_usage = psutil.cpu_percent()
    ram_usage = psutil.virtual_memory().percent
    disk_usage = psutil.disk_usage('/').percent
    
    threat_count = len(logs)
    quarantined = sum(1 for log in logs if 'Quarantined' in log[6] or 'Medium' in log[5])
    
    return render_template('index.html', cpu=cpu_usage, ram=ram_usage, disk=disk_usage, 
                           threats=threat_count, quarantined=quarantined)

@app.route('/logs')
def logs():
    logs = get_logs()
    return render_template('logs.html', logs=logs)

@app.route('/scan_file', methods=['POST'])
def scan_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    if file:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # 1. Signature Check
            file_hash = calculate_sha256(filepath)
            signature_match = file_hash in MALICIOUS_HASHES
            
            # 2. Extension Check
            suspicious_ext = is_suspicious_extension(filename)
            
            # 3. Entropy Check
            entropy = calculate_entropy(filepath)
            high_entropy = entropy > 7.5
            
            # Decision Logic
            is_malware = signature_match or suspicious_ext or (high_entropy and suspicious_ext)
             # Note: High entropy alone isn't malware (could be zip), but combined with other factors it is suspicious.
            
            risk_level = "Low"
            reason = "File appears safe."
            
            if signature_match:
                risk_level = "Critical"
                reason = "Matches known Ransomware Signature!"
                is_malware = True
            elif suspicious_ext:
                risk_level = "High"
                reason = "Suspicious file extension detected."
                is_malware = True
            elif high_entropy:
                risk_level = "Medium"
                reason = f"High Entropy ({entropy:.2f}). Possible packed/encrypted content."
            
            # Clean up
            os.remove(filepath)
            
            return jsonify({
                'filename': filename,
                'is_malware': is_malware,
                'risk_level': risk_level,
                'reason': reason,
                'details': {
                    'hash': file_hash,
                    'entropy': round(entropy, 2),
                    'extension_suspicious': suspicious_ext
                }
            })
            
        except Exception as e:
            if os.path.exists(filepath):
                os.remove(filepath)
            return jsonify({'error': str(e)})

@app.route('/api/stats')
def api_stats():
    # Real-time update via AJAX
    cpu_usage = psutil.cpu_percent()
    ram_usage = psutil.virtual_memory().percent
    
    logs = get_logs()
    high_threats = sum(1 for log in logs if log[5] == "High")
    medium_threats = sum(1 for log in logs if log[5] == "Medium")
    low_threats = sum(1 for log in logs if log[5] == "Low")
    
    return jsonify({
        'cpu': cpu_usage,
        'ram': ram_usage,
        'high': high_threats,
        'medium': medium_threats,
        'low': low_threats
    })

if __name__ == '__main__':
    start_background_monitoring()
    app.run(debug=True, use_reloader=False) # Disable reloader with threading
